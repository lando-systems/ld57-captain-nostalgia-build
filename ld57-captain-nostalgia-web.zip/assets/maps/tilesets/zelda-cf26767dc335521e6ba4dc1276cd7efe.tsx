<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="zelda" tilewidth="16" tileheight="16" spacing="1" margin="1" tilecount="256" columns="16">
 <image source="zelda_2_tiles.png" width="256" height="256"/>
</tileset>
