<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="mario" tilewidth="16" tileheight="16" spacing="1" margin="0" tilecount="900" columns="30">
 <image source="mario_3_tiles.png" width="512" height="512"/>
</tileset>
