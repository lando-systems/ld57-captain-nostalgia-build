<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="castlevania1" tilewidth="16" tileheight="16" spacing="1" tilecount="81" columns="9">
 <image source="castlevania_3_tiles_1.png" width="152" height="152"/>
</tileset>
