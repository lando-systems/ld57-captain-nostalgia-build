<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="garden" tilewidth="16" tileheight="16" tilecount="132" columns="11">
 <image source="tileset_garden.png" width="256" height="256"/>
</tileset>
