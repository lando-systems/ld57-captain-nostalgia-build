<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="library" tilewidth="16" tileheight="16" tilecount="143" columns="13">
 <image source="tileset_library.png" width="256" height="256"/>
</tileset>
